const _ = [
  // human
  `
llllll
ll l l
ll l l
llllll
 l  l
 l  l
  `,
  `
llllll
ll l l
ll l l
llllll
ll  ll
  `,
  `
  lll
ll l l
 llll
  ll
 l  l
 l  l
`,
  `
  lll
ll l l
 llll
 l  l
ll  ll
`,
  `
lllll
llllll
ll l l
lllll
 l  l
l   l
`,
  `
lllll
ll l l
llllll
lllll
 l  l
 l   l
`,
  `
  ll
  ll
llllll
  ll
 l  l
l    l
`,
  // arrow
  `
  l
   l
lllll
   l
  l
`,
  `
l
 l
  l l
   ll
  lll
`,
  `
ll  l
llllll
ll  l
  `,
  `
ll ll
 lllll
ll ll
  `,
  // coin
  `
l
l
l
  `,
  `
 l
lll
 l
  `,
  // heart
  `
 l l
lllll
lllll
 lll
  l
  `,
  // face
  `
 llll
l    l
ll  ll
l    l
l ll l
 llll 
`,
  // circle
  `
 ll
llll
llll
 ll
`,
  `
 ll
l  l
l  l
 ll
`,
  `
lll
lll
ll



`,
  `
llllll
llllll
lllll
lllll
llll
ll
`,
  `
  l
  l
ll



`,
  `
     l
     l
    l
    l
  ll
ll
`,
  // square
  `
llll
llll
llll
llll
`,
  `
llll
l  l
l  l
llll
`,
  `
l l l
 l l l
l l l
 l l l
l l l
 l l l
`,
  // triangle
  `
  l
 lll
 lll
lllll
lllll
`,
  `
  l
 l l
 l l
l   l
lllll
`,
  `
lll
ll
l



`,
  `
llllll
lllll
llll
lll
ll
l
`,
  `
l l l 
 l l
l l
 l
l
`,
  `
l l l 
 l l l
  l l
   l l
    l
     l
`,
  `
  l
 l
l



`,
  `
     l
    l
   l
  l
 l
l
`,
  // X
  `
l    l
 l  l
  ll
  ll
 l  l
l    l
`,
  // line
  `
  l
  l
  l
  l
  l
  l  
`,
  `
  l
  l
lll



`,
  `
  l
  l
llllll



`,
  `
  l
  l
lllllll
  l
  l
  l
` // dots
  `
lll
lll
lll



`,
  `
llllll
llllll
llllll



`,
  `
lll
lll
lll
   lll
   lll
   lll
`,
];
