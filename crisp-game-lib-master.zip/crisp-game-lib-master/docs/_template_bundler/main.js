import "crisp-game-lib";

const title = "";

const description = `
`;

const characters = [];

function update() {
  if (!ticks) {
  }
}

init({
  update,
  title,
  description,
  characters,
  options: {},
});
